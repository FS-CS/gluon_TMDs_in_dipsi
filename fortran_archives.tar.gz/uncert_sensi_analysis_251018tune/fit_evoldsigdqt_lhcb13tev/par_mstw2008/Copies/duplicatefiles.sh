# script that runs function duplicate to create 60 copies of file mstw2008lo.00.dat as mstw2008lo.00_1.dat,...,mstw2008lo.00_50.dat
# to run it, enter command : bash duplicatefiles.sh

function duplicate () {
    a=$1
    for i in $(seq 1 $2)
    do
#        echo ${a:0:13}_$i${a:13:4}
        cp $1 "${a:0:13}_$i${a:13:4}"
    done
}

duplicate mstw2008lo.00.dat 60

